namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double total;
        string op;
        private void one_Click(object sender, EventArgs e)
        {
         
                textBox1.Text =textBox1.Text + "1";
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void zero_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";

        }

        private void two_Click(object sender, EventArgs e)
        {

           
                textBox1.Text = textBox1.Text + "2";

            
        }

        private void three_Click(object sender, EventArgs e)
        {

           
                textBox1.Text = textBox1.Text + "3";

           
        }

        private void four_Click(object sender, EventArgs e)
        {

            
            
                textBox1.Text = textBox1.Text + "4";

        }

        private void five_Click(object sender, EventArgs e)
        {

           
                textBox1.Text = textBox1.Text + "5";

           
        }

        private void six_Click(object sender, EventArgs e)
        {

           
                textBox1.Text = textBox1.Text + "6";

          
        }

        private void seven_Click(object sender, EventArgs e)
        {

                textBox1.Text = textBox1.Text + "7";

        }

        private void eight_Click(object sender, EventArgs e)
        {

           
         
                textBox1.Text = textBox1.Text + "8";

            
        }

        private void nine_Click(object sender, EventArgs e)
        {

            
                textBox1.Text = textBox1.Text + "9";

           
        }

        private void dot_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ".";
        }

        private void add_Click(object sender, EventArgs e)
        {
            op = "+";
            total = double.Parse(textBox1.Text);
            textBox1.Text = "";
            if (label1.Text == "")
            {
                label1.Text = Convert.ToString(total) + " +";
            }
            else
            {
                label1.Text = label1.Text + Convert.ToString(total) + " +";
            }
        }

        private void sub_Click(object sender, EventArgs e)
        {

            op = "-";
            total = double.Parse(textBox1.Text);
            textBox1.Text = "";
            if (label1.Text == "")
            {
                label1.Text = Convert.ToString(total) + " -";
            }
            else
            {
                label1.Text = label1.Text + Convert.ToString(total) + " -";
            }
        }

        private void mul_Click(object sender, EventArgs e)
        {

            op = "*";
            total = double.Parse(textBox1.Text);
            textBox1.Text = "";
            if (label1.Text == "")
            {
                label1.Text = Convert.ToString(total) + " *";
            }
            else
            {
                label1.Text = label1.Text + Convert.ToString(total) + " *";
            }
        }

        private void subt_Click(object sender, EventArgs e)
        {

            op = "/";
            total = double.Parse(textBox1.Text);
            textBox1.Text = "";
            if (label1.Text == "")
            {
                label1.Text = Convert.ToString(total) + " /";
            }
            else
            {
                label1.Text = label1.Text + Convert.ToString(total) + " /";
            }
        }

        private void equal_Click(object sender, EventArgs e)
        {
            double finalresult;
            double total2;
            if(op== "+")
            {
                total2 = double.Parse(textBox1.Text);
                finalresult= total2+total;
                textBox1.Text =  Convert.ToString(finalresult);
                label1.Text = label1.Text + Convert.ToString(total2) + " = " + Convert.ToString(finalresult);

            }
            else if(op== "-")
            {
                total2 = double.Parse(textBox1.Text);
                finalresult =  total- total2;
                textBox1.Text = Convert.ToString(finalresult);
                label1.Text = label1.Text + Convert.ToString(total2) + " = " + Convert.ToString(finalresult);
            }
            else if (op == "*")
            {
                total2 = double.Parse(textBox1.Text);
                finalresult = total * total2;
                textBox1.Text = Convert.ToString(finalresult);
                label1.Text = label1.Text + Convert.ToString(total2)+ " = " + Convert.ToString(finalresult);
            }
            else if (op == "/")
            {
                total2 = double.Parse(textBox1.Text);
                finalresult = total / total2;
                textBox1.Text = Convert.ToString(finalresult);
                label1.Text = label1.Text + Convert.ToString(total2) + " = " + Convert.ToString(finalresult);
            }
            else 
            {
                
                textBox1.Text = Convert.ToString(total);
            }
            

        }

        private void clear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            total = 0;
            op = "";
            label1.Text = "";
        }

        private void ce_Click(object sender, EventArgs e)
        {
            string number=textBox1.Text;
            textBox1.Text = number.Remove(number.Length-1,1);
           
        }
    }
}